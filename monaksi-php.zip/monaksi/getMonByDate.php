<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['TGL_NOW']) &&
    isset($_POST['ID_SUBRAPAT'])
) {
    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];
    $TGL_NOW = $_POST['TGL_NOW'];

    $result = $db->getMonByDate($ID_SUBRAPAT, $TGL_NOW);
    if ($result)
        $response['data'] = $result;
    else
        $response['message'] = 'Not Found!';
} else {
    $response['message'] = 'Required Paramter "id_subrapat", "tgl_now" are missing.';
}
echo json_encode($response);
