<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (isset($_POST['id_agenda'])) {
    $id_agenda = $_POST['id_agenda'];

    $agenda = $db->getNamaAgenda($id_agenda);
    if ($agenda) {
        $response['id_agenda'] = $agenda['id_agenda'];
        $response['nama_agenda'] = $agenda['nama_agenda'];
    } else
        $response['message'] = 'User not found';
} else
    $response['message'] = 'Required Paramter "id_agenda" is missing.';


echo json_encode($response);
