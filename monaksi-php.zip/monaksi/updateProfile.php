<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama']) &&
    isset($_POST['username']) &&
    isset($_POST['email']) &&
    isset($_POST['id_user'])
) {
    $nama = $_POST['nama'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $id_user = $_POST['id_user'];

    $result = $db->updateProfile($nama, $username, $email, $id_user);
        if ($result)
            $response['message'] = 'Updated successfully';
        else
            $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_user" is missing.';

echo json_encode($response);
