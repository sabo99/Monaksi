<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (isset($_POST['nama'])) {
    $nama = $_POST['nama'];

    $user = $db->getUserByNama($nama);
    if ($user) {
        $response['id_user'] = $user['id_user'];
        $response['username'] = $user['username'];
        $response['nama'] = $user['nama'];
    } else
        $response['message'] = 'User not found';
} else
    $response['message'] = 'Required Paramter "nama" is missing.';


echo json_encode($response);
