<?php

require_once 'db_function.php';
$db = new DB_Functions();

// Spinner
$response = array();
if (isset($_POST['id_subrapat'])) {
    $ID_SUBRAPAT = $_POST['id_subrapat'];

    $allAgenda = $db->getAllAgenda($ID_SUBRAPAT);
    if ($allAgenda)
        $response['allAgenda'] = $allAgenda;
    else
        $response['message'] = 'Data Not Found!';
}
else
    $response['message'] = 'Required Paramter "id_subrapat" is missing.';


echo json_encode($response);
