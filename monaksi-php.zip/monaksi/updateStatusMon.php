<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON']) &&
    isset($_POST['LAST_STATUS']) &&
    isset($_POST['KOMENTAR'])
) {
    $ID_MON = $_POST['ID_MON'];
    $LAST_STATUS = $_POST['LAST_STATUS'];
    $KOMENTAR = $_POST['KOMENTAR'];

    $result = $db->updateStatusMon($ID_MON, $LAST_STATUS, $KOMENTAR);

    if ($result)
        $response['message'] = 'Updated successfully';
    else
        $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_mon", "last_status", "komentar" are missing.';

echo json_encode($response);
