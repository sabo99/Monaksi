<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama_subrapat']) &&
    isset($_POST['id_rapat'])
) {

    $nama_subrapat = $_POST['nama_subrapat'];
    $id_rapat = $_POST['id_rapat'];

    $subrapat = $db->getIdSubrapat($nama_subrapat, $id_rapat);
    if ($subrapat) {
        $response['id_subrapat'] = $subrapat['id_subrapat'];
        $response['nama_subrapat'] = $subrapat['nama_subrapat'];
        $response['id_rapat'] = $subrapat['id_rapat'];
        $response['status'] = $subrapat['status'];
    } else
        $response['message'] = 'Jabatan not Found!';
} else
    $response['message'] = 'Required Paramter "nama_subrapat" is missing.';


echo json_encode($response);
