<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama_rapat']) &&
    isset($_POST['nama_subrapat']) &&
    isset($_POST['id_subrapat'])
) {
    $nama_rapat = $_POST['nama_rapat'];
    $nama_subrapat = $_POST['nama_subrapat'];
    $id_subrapat = $_POST['id_subrapat'];

    $result = $db->getProgramID($nama_rapat, $nama_subrapat, $id_subrapat);
    if ($result)
        $response['PROG_ID'] = $result;
    else
        $response['message'] = 'User not found';
} else
    $response['message'] = 'Required Paramter "id_subrapat", "nama_subrapat", "nama_rapat" are missing.';


echo json_encode($response);
