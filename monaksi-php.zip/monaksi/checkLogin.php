<?php

require_once 'db_function.php';

$db = new DB_Functions();

$response = array();

if (isset($_POST['username']) &&
    isset($_POST['password'])) {

    $username = $_POST['username'];
    $password = md5($_POST['password']);
   
    if ($db->checkLogin($username, $password)) {
        $response['exists'] = true;
        $response['message'] = 'Login Berhasil';
    } else {
       $response['exists'] = false;
       $response['message'] = 'NIP atau Password anda salah!';
    }
} else {
    $response['message'] = 'Required Paramter "username", "password" are missing.';
}

echo json_encode($response);
