<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();
if (isset($_POST['ID_SUBRAPAT'])) {

    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];

    $data = $db->getAllMonitoring($ID_SUBRAPAT);
    if ($data)
        $response['data'] = $data;
    else
        $response['message'] = 'Data Not Found!';
} else
    $response['message'] = 'Required Paramter "id_subrapat" is missing.';


echo json_encode($response);
