<?php

require_once 'db_function.php';

$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_SUBRAPAT']) &&
    isset($_POST['ID_AGENDA']) &&
    isset($_POST['PROG_ID']) &&
    isset($_POST['TGL_REPORT']) &&
    isset($_POST['TGL_TARGET']) &&
    isset($_POST['KEPUTUSAN']) &&
    isset($_POST['PIC']) &&
    isset($_POST['APPROVAL']) &&
    isset($_POST['VERIFIKATOR']) &&
    isset($_POST['LAST_STATUS']) &&
    isset($_POST['LAST_UPDATES']) 
) {

    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];
    $ID_AGENDA = $_POST['ID_AGENDA'];
    $PROG_ID = $_POST['PROG_ID'];
    $TGL_REPORT = $_POST['TGL_REPORT'];
    $TGL_TARGET = $_POST['TGL_TARGET'];
    $KEPUTUSAN = $_POST['KEPUTUSAN'];
    $PIC = $_POST['PIC'];
    $APPROVAL = $_POST['APPROVAL'];
    $VERIFIKATOR = $_POST['VERIFIKATOR'];
    $LAST_STATUS = $_POST['LAST_STATUS'];
    $LAST_UPDATES = $_POST['LAST_UPDATES'];

    $task = $db->inputKeputusan($ID_SUBRAPAT, $ID_AGENDA, $PROG_ID, $TGL_REPORT, $TGL_TARGET, $KEPUTUSAN, $PIC, $APPROVAL, $VERIFIKATOR, $LAST_STATUS, $LAST_UPDATES);
    if ($task) {
        $response['message'] = 'Inserted successfully';
    } else {
        $response['message'] = 'Something Error with Inserted';
    }
} else {
    $response['message'] = 'Some required parameters are missing';
}

echo json_encode($response);
