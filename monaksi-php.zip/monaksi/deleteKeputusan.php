<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();
if (isset($_POST['ID_MON']) &&
isset($_POST['LAMPIRAN'])) {
    $ID_MON = $_POST['ID_MON'];
    $LAMPIRAN = $_POST['LAMPIRAN'];

    $result = $db->deleteKeputusan($ID_MON);
    $dir = './assets/'. $LAMPIRAN ;

    if ($result){
        if(file_exists($dir))
            unlink($dir);
            
        $response['message'] = 'Deleted successfuly';
    }
    else
        $response['message'] = 'Something Error with Deleted';
} else
    $response['message'] = 'Required Paramter "ID_MON" is missing.';


echo json_encode($response);