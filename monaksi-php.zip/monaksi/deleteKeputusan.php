<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();
if (isset($_POST['ID_MON'])) {
    $ID_MON = $_POST['ID_MON'];

    $result = $db->deleteKeputusan($ID_MON);

    if ($result)
        $response['message'] = 'Deleted successfuly';
    else
        $response['message'] = 'Something Error with Deleted';
} else
    $response['message'] = 'Required Paramter "ID_MON" is missing.';


echo json_encode($response);
