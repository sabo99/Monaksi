<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['id_user']) &&
    isset($_POST['status']) &&
    isset($_POST['lastLogin'])
) {
    $id_user = $_POST['id_user'];
    $status = $_POST['status'];
    $lastLogin = $_POST['lastLogin'];

    $result = $db->updateStatusUser($status, $id_user, $lastLogin);

    if ($result)
        $response['message'] = 'Updated successfully';
    else
        $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_mon", "status", "lastLogin" are missing.';

echo json_encode($response);
