<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_SUBRAPAT']) &&
    isset($_POST['APPROVAL'])
) {

    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];
    $APPROVAL = $_POST['APPROVAL'];

    $result = $db->getApproval($ID_SUBRAPAT, $APPROVAL);
    if ($result)
        $response['data'] = $result;
    else
        $response['message'] = 'Not Found!';
} else {
    $response['message'] = 'Required Paramter "id_subrapat", "approval" are missing.';
}
echo json_encode($response);
