<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_SUBRAPAT']) &&
    isset($_POST['VERIFIKATOR'])
) {

    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];
    $VERIFIKATOR = $_POST['VERIFIKATOR'];

    $result = $db->getVerifikasi($ID_SUBRAPAT, $VERIFIKATOR);
    if ($result)
        $response['data'] = $result;
    else
        $response['message'] = 'Not Found!';
} else 
    $response['message'] = 'Required Paramter "id_subrapat", "verifikator" are missing.';

echo json_encode($response);
