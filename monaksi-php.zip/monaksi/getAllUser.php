<?php 

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();
$allUser = $db->getAllUser();
if ($allUser) 
    $response['allUser'] = $allUser;
else
    $response['message'] = 'Data Not Found!';

echo json_encode($response);

?>