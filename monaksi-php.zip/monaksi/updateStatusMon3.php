<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON']) &&
    isset($_POST['TGL_SELESAI']) &&
    isset($_POST['LAST_STATUS'])
) {
    $ID_MON = $_POST['ID_MON'];
    $TGL_SELESAI = $_POST['TGL_SELESAI'];
    $LAST_STATUS = $_POST['LAST_STATUS'];

    $result = $db->updateStatusMon3($ID_MON, $TGL_SELESAI, $LAST_STATUS);

    if ($result)
        $response['message'] = 'Updated successfully';
    else
        $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_mon", "last_status", "tgl_selesai" are missing.';

echo json_encode($response);
