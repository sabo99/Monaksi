<?php

require_once 'db_function.php';

$db = new DB_Functions();

$response = array();

if (isset($_POST['username'])){

    $username = $_POST['username'];
   
    if ($db->checkExistsUser($username)) {
        $response['exists'] = true;
    } else {
       $response['exists'] = false;
    }
} else {
    $response['message'] = 'Required Paramter "username" is missing.';
}

echo json_encode($response);
