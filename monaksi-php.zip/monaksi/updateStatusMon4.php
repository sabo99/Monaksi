<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON']) &&
    isset($_POST['TGL_APPROVAL']) &&
    isset($_POST['KOMENTAR']) &&
    isset($_POST['LAST_STATUS'])
) {
    $ID_MON = $_POST['ID_MON'];
    $TGL_APPROVAL = $_POST['TGL_APPROVAL'];
    $KOMENTAR = $_POST['KOMENTAR'];
    $LAST_STATUS = $_POST['LAST_STATUS'];

    $result = $db->updateStatusMon4($ID_MON, $TGL_APPROVAL, $KOMENTAR, $LAST_STATUS);

    if ($result) {
        $response['message'] = 'Update Succesfully';
    } else {
        $response['message'] = 'Something error with update';
    }
} else
    $response['message'] = 'Required Paramter';
echo json_encode($response);
