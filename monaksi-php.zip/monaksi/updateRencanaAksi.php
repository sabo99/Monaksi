<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON']) &&
    isset($_POST['RENCANA_AKSI'])
) {
    $ID_MON = $_POST['ID_MON'];
    $RENCANA_AKSI = $_POST['RENCANA_AKSI'];

    $result = $db->updateRencanaAksi($ID_MON, $RENCANA_AKSI);

    if ($result)
        $response['message'] = 'Updated successfully';
    else
        $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_mon", "rencana_aksi" are missing.';

echo json_encode($response);
