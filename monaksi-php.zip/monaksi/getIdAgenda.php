<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama_agenda'])
) {

    // Get ID_Agenda check From nama_agenda
    $nama_agenda = $_POST['nama_agenda'];

    $agenda = $db->getIdAgenda($nama_agenda);
    if ($agenda) {
        $response['id_agenda'] = $agenda['id_agenda'];
        $response['id_subrapat'] = $agenda['id_subrapat'];
        $response['nama_agenda'] = $agenda['nama_agenda'];
        $response['tanggal_agenda'] = $agenda['tanggal_agenda'];
        $response['status'] = $agenda['status'];

    } else
        $response['message'] = 'Jabatan not Found!';
} else {
    $response['message'] = 'Required Paramter "nama_agenda" is missing.';
}

echo json_encode($response);
