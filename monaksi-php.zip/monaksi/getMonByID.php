<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON'])
) {

    $ID_MON = $_POST['ID_MON'];

    $Monitoring = $db->getMonByID($ID_MON);
    if ($Monitoring){
        $response = $Monitoring;
    }
    else
        $response['message'] = 'Not Found!';
} else {
    $response['message'] = 'Required Paramter "id_mon" is missing.';
}
echo json_encode($response);
