<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama_rapat'])
) {
    $nama_rapat = $_POST['nama_rapat'];

    $rapat = $db->getIdRapat($nama_rapat);
    if ($rapat) {
        $response['id_rapat'] = $rapat['id_rapat'];
        $response['nama_rapat'] = $rapat['nama_rapat'];
        $response['status'] = $rapat['status'];

    } else
        $response['message'] = 'Jabatan not Found!';
} else {
    $response['message'] = 'Required Paramter "nama_rapat" is missing.';
}

echo json_encode($response);
