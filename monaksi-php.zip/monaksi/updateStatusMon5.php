<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_MON']) &&
    isset($_POST['TGL_CLOSED']) &&
    isset($_POST['KOMENTAR']) &&
    isset($_POST['LAST_STATUS'])
) {
    $ID_MON = $_POST['ID_MON'];
    $TGL_CLOSED = $_POST['TGL_CLOSED'];
    $KOMENTAR = $_POST['KOMENTAR'];
    $LAST_STATUS = $_POST['LAST_STATUS'];

    $result = $db->updateStatusMon5($ID_MON, $TGL_CLOSED,  $KOMENTAR, $LAST_STATUS);

    if ($result)
        $response['message'] = 'Update Succesfully';
    else
        $response['message'] = 'Something error with update';
} else
    $response['message'] = 'Required Paramter "id_mon", "last_status", "komentar", "tgl_closed" are missing.';

echo json_encode($response);
