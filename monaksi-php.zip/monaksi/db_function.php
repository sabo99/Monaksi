<?php

class DB_Functions
{
	private $conn;

	function __construct()
	{

		require_once 'db_connect.php';

		$db = new DB_Connect();
		$this->conn = $db->connect();
	}
	
	/**
	 * GET Count Monitoring By ID_SUBRAPAT & LAST_STATUS
	 * 
	 * GET Data for Pie Chart
	 */
	 
	 /**
	  * GET Count Revisi, Belum Dikerjakan, On Progress, Selesai, Approved, Verified
	  */

	function getCount($ID_SUBRAPAT, $LAST_STATUS){
		$stmt = $this->conn->prepare("SELECT COUNT(?) AS quantity FROM tblkit_monitoring WHERE ID_SUBRAPAT=? AND LAST_STATUS=?");
		$stmt->bind_param('sss', $ID_SUBRAPAT, $ID_SUBRAPAT, $LAST_STATUS);
		$result = $stmt->execute();
		
		if($result){
			$qty = $stmt->get_result()->fetch_assoc();
			
			return $qty;
			$stmt->close();
		   
		}
		else{
			return false;
		}
	}
	
	 
	/**
	 * Spinner Nama Agenda
	 * Call<ResponseModel>
	 */
	function getAllAgenda($ID_SUBRAPAT)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_agenda 
				WHERE ID_SUBRAPAT='" . $ID_SUBRAPAT . "'");
		$agenda = array();
		while ($item = $stmt->fetch_assoc())
			$agenda[] = $item;
		return $agenda;
	}

	function getIdAgenda($nama_agenda)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_agenda WHERE nama_agenda=?");
		$stmt->bind_param('s', $nama_agenda);

		if ($stmt->execute()) {

			$agenda = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $agenda;
		} else
			return false;
	}

	/**
	 * Spinner PIC, Approval, Verifikator
	 * 
	 * Call<ResponseModel> 
	 */

	function getAllUser()
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_user");
		$allUser = array();
		while ($item = $stmt->fetch_assoc())
			$allUser[] = $item;
		return $allUser;
	}

	/**
	 *  Get Username by Nama 
	 *  Call<UserModel>
	 */

	function getUserByNama($nama)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_user WHERE nama=?");
		$stmt->bind_param('s', $nama);

		if ($stmt->execute()) {

			$user = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $user;
		} else
			return false;
	}

	/**
	 * Get PROGRAM ID
	 */

	function getProgramID($nama_rapat, $nama_subrapat, $id_subrapat)
	{
		$stmt1 = $this->conn->prepare("SELECT * FROM tblkit_monitoring 
				WHERE ID_SUBRAPAT=? ORDER BY ID_MON DESC LIMIT 1");
		$stmt1->bind_param('s', $id_subrapat);
		$stmt1->execute();
		$result = $stmt1->get_result();

		if ($result->num_rows == 1) {
			$store = $result->fetch_assoc();
			$data1 = $store['PROG_ID'];

			$array = explode(".", $data1);
			$angkabaru = $array['1'] + 1;
			$stmt1->close();
		} else {
			$angkabaru = 1;
			$stmt1->close();
		}

		$stmt2 = $this->conn->prepare("SELECT * FROM tblkit_subrapat AS a, tblkit_unit AS b 
				WHERE a.nama_subrapat = b.nama_unit AND b.nama_unit=?");
		$stmt2->bind_param('s', $nama_subrapat);
		$stmt2->execute();

		$data2 = $stmt2->get_result()->fetch_assoc();
		$stmt2->close();
		switch ($nama_rapat) {
			case 'RAKOR':
				$awal = 'RKR';
				$akhir = $nama_subrapat;
				break;
			case 'RAPIM':
				$awal = 'RPM';
				$akhir = $data2['kode_unit'];
				break;
			case 'PROGRAM KERJA':
				$awal = 'PRO';
				$akhir = $data2['kode_unit'];
				break;
			case 'OFI':
				$awal = 'OFI';
				$akhir = $nama_subrapat;
				break;
			default:
				$awal = $nama_subrapat;
				$akhir = $data2['kode_unit'];
				break;
		}

		// $progID = 
		return $awal . $akhir . '.' . $angkabaru;
	}

	/**
	 * Admin / Operator INSERT Keputusan
	 * 
	 *  - Komentar = Keterangan
	 *  - Last status = 0 (Belum dikerjakan)
	 *  - TglReport = TglInsert
	 */
	function inputKeputusan(
		$ID_SUBRAPAT,
		$ID_AGENDA,
		$PROG_ID,
		$TGL_REPORT,
		$TGL_TARGET,
		$KEPUTUSAN,
		$PIC,
		$APPROVAL,
		$VERIFIKATOR,
		$LAST_STATUS,
		$LAST_UPDATES
	) {
		$stmt = $this->conn->prepare("INSERT INTO `tblkit_monitoring` (ID_SUBRAPAT, ID_AGENDA, PROG_ID, 
			TGL_REPORT, TGL_TARGET, KEPUTUSAN, PIC, APPROVAL, VERIFIKATOR, LAST_STATUS, LAST_UPDATES) 
			VALUES(?,?,?,?,?,?,?,?,?,?,?)");
		$stmt->bind_param(
			'sssssssssss',
			$ID_SUBRAPAT,
			$ID_AGENDA,
			$PROG_ID,
			$TGL_REPORT,
			$TGL_TARGET,
			$KEPUTUSAN,
			$PIC,
			$APPROVAL,
			$VERIFIKATOR,
			$LAST_STATUS,
			$LAST_UPDATES
		);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	/**
	 *  Admin / Operator UPDATE Keputusan
	 *  TglReport : TglInsert
	 */

	function updateKeputusan(
		$ID_SUBRAPAT,
		$ID_AGENDA,
		$PROG_ID,
		$TGL_REPORT,
		$TGL_TARGET,
		$KEPUTUSAN,
		$PIC,
		$APPROVAL,
		$VERIFIKATOR,
		$LAST_STATUS,
		$LAST_UPDATES,
		$ID_MON
	) {
		$stmt =
			$this->conn->prepare("UPDATE tblkit_monitoring SET ID_SUBRAPAT=?, 
				ID_AGENDA=?, PROG_ID=?, TGL_REPORT=?, TGL_TARGET=?, KEPUTUSAN=?,
				PIC=?, APPROVAL=?, VERIFIKATOR=?, LAST_STATUS=?, LAST_UPDATES=?
				WHERE ID_MON=?");
		$stmt->bind_param(
			'ssssssssssss',
			$ID_SUBRAPAT,
			$ID_AGENDA,
			$PROG_ID,
			$TGL_REPORT,
			$TGL_TARGET,
			$KEPUTUSAN,
			$PIC,
			$APPROVAL,
			$VERIFIKATOR,
			$LAST_STATUS,
			$LAST_UPDATES,
			$ID_MON
		);

		$result = $stmt->execute();
		$stmt->close();
		return $result;
	}


	function deleteKeputusan($ID_MON)
	{
		$stmt = $this->conn->prepare("DELETE FROM tblkit_monitoring WHERE ID_MON=?");
		$stmt->bind_param('s', $ID_MON);
		$result = $stmt->execute();

		return $result;
	}


	/**
	 * tblkit_user
	 * Check Login (Username, Password)
	 * Check For Login User
	 */

	function checkLogin($username, $password)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_user WHERE username=? AND password=?");
		$stmt->bind_param('ss', $username, $password);
		$stmt->execute();
		$stmt->store_result();

		if ($stmt->num_rows > 0) {
			$stmt->close();
			return $stmt;
		} else {
			$stmt->close();
			return false;
		}
	}

	/**
	 *  Check Exists User (Username)
	 *  if already not insert LOG USER
	 */
	function checkExistsUser($username)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_user WHERE username=?");
		$stmt->bind_param('s', $username);
		$stmt->execute();
		$stmt->store_result();

		if ($stmt->num_rows > 0) {
			$stmt->close();
			return true;
		} else {
			$stmt->close();
			return false;
		}
	}

	// Call<UserModel>
	/**
	 *  Get UserInfo By Username
	 */
	function getUserInformation($username)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_user WHERE username=?");
		$stmt->bind_param('s', $username);

		if ($stmt->execute()) {

			$user = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $user;
		} else
			return false;
	}


	// Call<ResponseModel>
	/**
	 * Update Status User for Login
	 *  - If Status "ON" user already Login
	 */
	function updateStatusUser($status, $id_user, $lastLogin)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_user SET status=?, lastLogin=?
				WHERE id_user=?");
		$stmt->bind_param('sss', $status, $lastLogin, $id_user);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}


	// Call<ResponseModel>
	/**
	 * Update Password User
	 */
	function updatePassword($password, $id_user)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_user SET password=?
				WHERE id_user=?");
		$stmt->bind_param('ss', $password, $id_user);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	// Call<ResponseModel>
	/**
	 * Update Profile User by ID_USER
	 *  Variable :
	 *  - Nama, Username, email
	 */
	function updateProfile($nama, $username, $email, $id_user)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_user SET nama=?, username=?, email=?
				WHERE id_user=?");
		$stmt->bind_param('ssss', $nama, $username, $email, $id_user);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}


	/**
	 *  Table Monitoring
	 */
	// tblkit_monitoring
	// ===========================================

	// 
	// 
	// Call<ResponseModel>
	/**
	 *  Menu List
	 *  - SELECT * FROM tblkit_monitoring WHERE ID_SUBRAPAT=? ORDER BY ID_MON DESC
	 *  Variable :
	 *  - ID_SUBRAPAT
	 */
	function getAllMonitoring($ID_SUBRAPAT)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring WHERE ID_SUBRAPAT='" . $ID_SUBRAPAT . "' ORDER BY ID_MON DESC");
		$mon = array();
		while ($item = $stmt->fetch_assoc())
			$mon[] = $item;
		return $mon;
	}

	// Call<ResponseModel>
	/**
	 *  Menu List Spinner Status 
	 *  (Belum dikerjakan, On Progress, Selesai, Approved, Verified)
	 *  - SELECT * FROM tblkit_monitoring 
	 *     WHERE LAST_STATUS=? AND ID_SUBRAPAT=? ORDER BY ID_MON DESC
	 */
	function getMonByStatus($ID_SUBRAPAT, $LAST_STATUS)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring 
				WHERE ID_SUBRAPAT='" . $ID_SUBRAPAT . "' 
				AND LAST_STATUS='" . $LAST_STATUS . "' ORDER BY ID_MON DESC");
		$mon = array();
		while ($item = $stmt->fetch_assoc())
			$mon[] = $item;
		return $mon;
	}

	// Call<ResponseModel>
	/**
	 *  Menu List Spinner Backlog (Melebihi tgl Target)
	 *  - SELECT * FROM tblkit_monitoring 
	 *			WHERE TGL_TARGET < '" . $TGL_NOW . "' AND ID_SUBRAPAT=? ORDER BY ID_MON DESC
	 */
	function getMonByDate($ID_SUBRAPAT, $TGL_NOW)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring 
				WHERE ID_SUBRAPAT='" . $ID_SUBRAPAT . "'
				AND TGL_TARGET < '" . $TGL_NOW . "' 
				AND NOT LAST_STATUS = '3'
				AND NOT LAST_STATUS = '4'
				AND NOT LAST_STATUS = '5' ORDER BY ID_MON DESC");
		$mon = array();
		while ($item = $stmt->fetch_assoc())
			$mon[] = $item;
		return $mon;
	}

	// Call<AgendaModel>
	/**
	 * Get Nama Agenda For Detail Activity
	 */
	function getNamaAgenda($ID_AGENDA)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_agenda WHERE id_agenda=?");
		$stmt->bind_param('s', $ID_AGENDA);

		if ($stmt->execute()) {
			$agenda = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $agenda;
		} else
			return false;
	}


	// ===============================================================

	// Menu Task
	// Call<ResponseModel>
	/**
	 *  
	 *  - SELECT * FROM tblkit_monitoring WHERE PIC='".$PIC."' AND ID_SUBRAPAT=?
	 *     ORDER BY ID_MON DESC
	 *  Variable :
	 *  - PIC, ID_SUBRAPAT
	 */
	function getTask($ID_SUBRAPAT, $PIC)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring WHERE 
					ID_SUBRAPAT='" . $ID_SUBRAPAT . "' AND	PIC='" . $PIC . "' 
					 ORDER BY ID_MON DESC");
		$task = array();
		while ($item = $stmt->fetch_assoc())
			$task[] = $item;
		return $task;
	}

	// Menu Approval
	// Call<ResponseModel>
	/**
	 * 
	 *  - SELECT * FROM tblkit_monitoring WHERE APPROVAL='".$APPROVAL."' AND ID_SUBRAPAT=?
	 *     ORDER BY ID_MON DESC
	 *  Variable :
	 *  - APPROVAL, ID_SUBRAPAT
	 */
	function getApproval($ID_SUBRAPAT, $APPROVAL)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring WHERE 
					ID_SUBRAPAT='" . $ID_SUBRAPAT . "' AND APPROVAL='" . $APPROVAL . "' 
					 AND LAST_STATUS = '3' ORDER BY ID_MON DESC");
		$approval = array();
		while ($item = $stmt->fetch_assoc())
			$approval[] = $item;
		return $approval;
	}

	// Menu Verifikasi
	// Call<ResponseModel>
	/**
	 * 
	 *  - SELECT * FROM tblkit_monitoring WHERE VERIFIKATOR='".$VERIFIKATOR."' AND ID_SUBRAPAT=?
	 *     ORDER BY ID_MON DESC
	 *  Variable :
	 *  - VERIFIKATOR, ID_SUBRAPAT
	 */
	function getVerifikasi($ID_SUBRAPAT, $VERIFIKATOR)
	{
		$stmt = $this->conn->query("SELECT * FROM tblkit_monitoring WHERE 
		            ID_SUBRAPAT='" . $ID_SUBRAPAT . "' AND  VERIFIKATOR='" . $VERIFIKATOR . "' 
					 AND LAST_STATUS = '4' ORDER BY ID_MON DESC");
		$verfied = array();
		while ($item = $stmt->fetch_assoc())
			$verfied[] = $item;
		return $verfied;
	}


	/**
	 * Get Monitoring By ID_MON 
	 *  - for DetailTask, DetailApproval, DetailVerfikator
	 *  Variable :
	 *  - ID_MON
	 * 
	 *  Call<Monitoring>
	 */

	function getMonByID($ID_MON)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_monitoring 
				WHERE ID_MON=?");
		$stmt->bind_param('s', $ID_MON);

		if ($stmt->execute()) {
			$agenda = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $agenda;
		} else
			return false;
	}

	/**
	 * Update Status Monitoring (PIC / Task)
	 * Variable :
	 *  - ID_MON, LAST_STATUS
	 * 
	 *  Call<ResponseModel>
	 */

	// On Progress || bs digunakan untuk update Status menjadi Revisi
	function updateStatusMon($ID_MON, $LAST_STATUS, $KOMENTAR)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_monitoring SET LAST_STATUS=?, KOMENTAR=?
				WHERE ID_MON=?");
		$stmt->bind_param('sss', $LAST_STATUS, $KOMENTAR, $ID_MON);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	/**
	 *  Selesai
	 */
	function updateStatusMon3($ID_MON, $TGL_SELESAI, $LAST_STATUS)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_monitoring SET 
				TGL_SELESAI=?, LAST_STATUS=?  
				WHERE ID_MON=?");
		$stmt->bind_param('sss', $TGL_SELESAI, $LAST_STATUS, $ID_MON);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	/**
	 * Approved
	 */
	function updateStatusMon4($ID_MON, $TGL_APPROVAL, $KOMENTAR, $LAST_STATUS)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_monitoring SET
				TGL_APPROVAL=?, KOMENTAR=?, LAST_STATUS=?
				WHERE ID_MON=?");
		$stmt->bind_param('ssss', $TGL_APPROVAL, $KOMENTAR, $LAST_STATUS, $ID_MON);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	/**
	 * Verified
	 */
	function updateStatusMon5($ID_MON, $TGL_CLOSED,  $KOMENTAR, $LAST_STATUS)
	{
		$stmt = $this->conn->prepare("UPDATE tblkit_monitoring SET
	 		 TGL_CLOSED=?, KOMENTAR=?, LAST_STATUS=?
	 		 WHERE ID_MON=?");
		$stmt->bind_param('ssss', $TGL_CLOSED,  $KOMENTAR, $LAST_STATUS, $ID_MON);
		$result = $stmt->execute();
		$stmt->close();

		return $result;
	}

	// Lampiran text name of FILE
	// Call<String> , with ScalarsConverter
	/**
	 *  Upload File Monitoring
	 */
	function sendFile($ID_MON, $fileName)
	{
		$result =
			$this->conn->query("UPDATE tblkit_monitoring SET LAMPIRAN='$fileName'
					WHERE ID_MON='$ID_MON'");
		return $result;
	}

	/**
	 * Rencana Aksi
	 * Call<ResponseModel>
	 * 
	 * Update Rencana Aksi
	 */

	function updateRencanaAksi($ID_MON, $RENCANA_AKSI)
	{
		$query = "UPDATE tblkit_monitoring SET RENCANA_AKSI='$RENCANA_AKSI'
			WHERE ID_MON='$ID_MON'";
		$result = $this->conn->query($query);
		return $result;
	}


	/**
	 * Spinner Rapat in MainActivity
	 * Get Rapat & Subrapat by ID_JABATAN = ID_USER from Role
	 *  Variable :
	 *  - ID_USER
	 */

	function getJabatan($id_user)
	{
		$query = "SELECT * FROM tblkit_jabatan WHERE id_user=?";

		$stmt = $this->conn->prepare($query);
		$stmt->bind_param('s', $id_user);

		if ($stmt->execute()) {
			$jabatan = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $jabatan;
		} else
			return false;
	}

	function getAllRapatAktif($sess_jabatan)
	{
		$query = "SELECT DISTINCT a.nama_rapat, a.id_rapat FROM 
        		tblkit_rapat AS a,
        		tblkit_subrapat AS b,
        		tblkit_jabatan AS c,
        		tblkit_role AS d
         		WHERE
				a.id_rapat=b.id_rapat AND 
				b.id_subrapat=d.id_subrapat AND
				c.id_jabatan=d.id_jabatan AND 
				d.id_jabatan='$sess_jabatan'
				ORDER BY a.id_rapat";

		$stmt = $this->conn->query($query);

		$rapat = array();
		while ($item = $stmt->fetch_assoc())
			$rapat[] = $item;
		return $rapat;
	}

	// Get ID RAPAT for sess_rapat
	function getIdRapat($nama_rapat)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_rapat 
				WHERE nama_rapat=?");
		$stmt->bind_param('s', $nama_rapat);

		if ($stmt->execute()) {
			$rapat = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $rapat;
		} else
			return false;
	}


	function subrapatAktif($sess_rapat, $sess_jabatan)
	{
		$query = "SELECT * FROM 
				tblkit_subrapat AS a, 
				tblkit_role AS b,
				tblkit_jabatan AS c 
				WHERE 
				a.id_subrapat=b.id_subrapat AND 
				a.id_rapat='$sess_rapat' AND 
				b.id_jabatan=c.id_jabatan AND 
				b.id_jabatan='$sess_jabatan'
				ORDER BY 
				a.id_subrapat";

		$stmt = $this->conn->query($query);

		$subrapat = array();
		while ($item = $stmt->fetch_assoc())
			$subrapat[] = $item;
		return $subrapat;
	}

	function getIdSubrapat($nama_subrapat, $id_rapat)
	{
		$stmt = $this->conn->prepare("SELECT * FROM tblkit_subrapat WHERE nama_subrapat=? AND id_rapat=?");
		$stmt->bind_param('ss', $nama_subrapat, $id_rapat);

		if ($stmt->execute()) {

			$subrapat = $stmt->get_result()->fetch_assoc();
			$stmt->close();

			return $subrapat;
		} else
			return false;
	}
	
	/**
	 * Insert LOG User
	 */ 
	function getIPAddress(){
	    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
			$ip_address = $_SERVER['HTTP_CLIENT_IP'];
		} elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
			$ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else {
			$ip_address = $_SERVER['REMOTE_ADDR'];
		}

		return $ip_address;
	}
	
	function insertLogUser($ip, $nama, $aksi, $waktu){

		$stmt = $this->conn->prepare("INSERT INTO tblkit_log (ip, nama, aksi, waktu) 
							VALUES(?, ?, ?, ?)");
		$stmt->bind_param('ssss', $ip, $nama, $aksi, $waktu);

		$result = $stmt->execute();
		$stmt->close();
		return $result;
	}
}
