<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (isset($_POST['username'])) {
    $username = $_POST['username'];

    $user = $db->getUserInformation($username);
    if ($user)
        $response = $user;
    else
        $response['message'] = 'User not found';
} else
    $response['message'] = 'Required Paramter "username" is missing.';


echo json_encode($response);
