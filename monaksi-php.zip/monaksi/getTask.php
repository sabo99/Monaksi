<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['ID_SUBRAPAT']) &&
    isset($_POST['PIC'])
) {

    $ID_SUBRAPAT = $_POST['ID_SUBRAPAT'];
    $PIC = $_POST['PIC'];

    $result = $db->getTask($ID_SUBRAPAT, $PIC);
    if ($result)
        $response['data'] = $result;
    else
        $response['message'] = 'Not Found!';
} else
    $response['message'] = 'Required Paramter "id_subrapat", "pic" are missing.';

echo json_encode($response);
