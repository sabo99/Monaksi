<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

// Subrapat AKTIF

if (
    isset($_POST['id_jabatan']) &&
    isset($_POST['id_rapat'])
) {

    $id_rapat = $_POST['id_rapat'];
    $id_jabatan = $_POST['id_jabatan'];

    $result = $db->subrapatAktif($id_rapat, $id_jabatan);
    if ($result)
        $response['allSubrapat'] = $result;
    else
        $response['message'] = 'Subrapat not Found!';
} else
    $response['message'] = 'Required Paramter "id_jabatan", "id_rapat" are missing.';


echo json_encode($response);
