<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['id_user']) &&
    isset($_POST['password'])
) {
    $id_user = $_POST['id_user'];
    $password = md5($_POST['password']);

    $result = $db->updatePassword($password, $id_user);

    if ($result)
        $response['message'] = 'Password berhasil diubah!';

    else
        $response['message'] = 'Something Error with Updated';
} else
    $response['message'] = 'Required Paramter "id_user", "password" are missing.';

echo json_encode($response);
