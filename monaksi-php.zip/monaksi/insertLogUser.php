<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['nama']) &&
    isset($_POST['aksi']) &&
    isset($_POST['waktu'])
) {
    $nama = $_POST['nama'];
    $aksi = $_POST['aksi'];
    $waktu = $_POST['waktu'];

    $ip = $db->getIPAddress();
    if ($ip) {
        $result = $db->insertLogUser($ip, $nama, $aksi, $waktu);
        if ($result)
            $response['message'] = 'Inserted Successfully.';
        else
            $response['message'] = 'Inserted Failed.';
    } else
        $response['message'] = 'Failed GET IP';
} else
    $response['message'] = 'Required Paramter "nama", "aksi", "waktu" are missing.';

echo json_encode($response);
