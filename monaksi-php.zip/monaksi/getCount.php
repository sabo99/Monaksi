<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['id_subrapat'])
) {
    $id_subrapat = $_POST['id_subrapat'];
    $last_status_0 = 0;
    $last_status_1 = 1;
    $last_status_2 = 2;
    $last_status_3 = 3;
    $last_status_4 = 4;
    $last_status_5 = 5;


    $revisi = $db->getCount($id_subrapat, $last_status_0);
    if ($revisi){
        $response['revisi'] = $revisi['quantity'];
    }
        
    $belum = $db->getCount($id_subrapat, $last_status_1);
    if ($belum){
        $response['belumdikerjakan'] = $belum['quantity'];
    }

    $onprogress = $db->getCount($id_subrapat, $last_status_2);
    if ($onprogress){
        $response['onprogress'] = $onprogress['quantity'];
    }

    $selesai = $db->getCount($id_subrapat, $last_status_3);
    if ($selesai){
        $response['selesai'] = $selesai['quantity'];
    }

    $approved = $db->getCount($id_subrapat, $last_status_4);
    if ($approved){
        $response['approved'] = $approved['quantity'];
    }

    $verified = $db->getCount($id_subrapat, $last_status_5);
    if ($verified){
        $response['verified'] = $verified['quantity'];
    }
        
} else
    $response['message'] = 'Required Paramter "id_subrapat" is missing.';

echo json_encode($response);
