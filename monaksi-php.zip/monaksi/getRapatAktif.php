<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['id_jabatan'])
) {

    $id_jabatan = $_POST['id_jabatan'];

    $result = $db->getAllRapatAktif($id_jabatan);
    if ($result)
        $response['allRapat'] = $result;
    else
        $response['message'] = 'Rapat not Found!';
} else
    $response['message'] = 'Required Paramter "id_jabatan" is missing.';


echo json_encode($response);
