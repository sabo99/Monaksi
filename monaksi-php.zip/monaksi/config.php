<?php 
	define('DB_HOST','localhost');
	define('DB_USER','id14821560_user_root');
	define('DB_PASSWORD','$M0n4k$i=0123');
	define('DB_DATABASE','id14821560_db_monaksiv001');
 ?>
