<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (isset($_FILES['file']['name'])) {
    if (
        isset($_POST['ID_MON']) &&
        isset($_POST['oldFileName'])
    ) {
        $ID_MON = $_POST['ID_MON'];
        $oldFileName = $_POST['oldFileName'];

        $name = $_FILES['file']['name'];
        $tmp_name = $_FILES['file']['tmp_name'];
        $error = $_FILES['file']['error'];

        if (!empty($name) && !empty($oldFileName)) {
            $location = './assets/';
            unlink($location . $oldFileName); // hapus file lama
            
            if (!is_dir($location))
                mkdir($location);
            if (move_uploaded_file($tmp_name, $location . $name)) {
                $result = $db->sendFile($ID_MON, $name);
                if ($result)
                    $response['message'] = 'Uploaded Success!';
                else
                    $response['message'] = 'Error while write to database : ' . $error;
            }
        }
    } else
        $response['message'] = 'Required Paramter "id_mon" is missing.';
} else
    $response['message'] = 'Please select file !';

echo json_encode($response);
