<?php

require_once 'db_function.php';
$db = new DB_Functions();

$response = array();

if (
    isset($_POST['id_user'])
) {

    $id_user = $_POST['id_user'];

    $resultJabatan = $db->getJabatan($id_user);
    if ($resultJabatan) {
        $response = $resultJabatan;
    } else
        $response['message'] = 'Jabatan not Found!';
} else {
    $response['message'] = 'Required Paramter "id_user" is missing.';
}

echo json_encode($response);
